# Intelligent Pattern Data Challenge Tasks
 ## Sales Forcasting📈📊

#### First, set up my environment by importing needed libraries.


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(style="darkgrid")
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import scipy.stats as stats
import statsmodels.api as sm
```

## Data prepration

#### “I downloaded the data from the provided link.
#### I used Jupyter Notebooks to create an HTML documentation of the project.
#### The dataset used for this case study includes 19 attributes and 2959 rows. 
#### The attributes contain customer information, material information,
#### and sale transaction details (Quantity, Qty_Sales,Unit price, Revenue, Net_Sales, Discounts, Sales date).”



```python
#### upload the  sales datasets which are xlsx  format .
### ‘read_excel’ function.

sale = pd.read_excel('Sales Data.xlsx')
```


```python
##show the first  rows of the data frame.

sale.head(2)
          

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Customer_Group</th>
      <th>Period</th>
      <th>PostDate</th>
      <th>Year</th>
      <th>Material ID</th>
      <th>Material_Descriptions</th>
      <th>Quantity</th>
      <th>Qty_Sales</th>
      <th>Unit price</th>
      <th>Revenue</th>
      <th>Discount</th>
      <th>DIS%</th>
      <th>Net_Sales</th>
      <th>Employee ID</th>
      <th>Quartar</th>
      <th>Purchasing Power</th>
      <th>Sales Value</th>
      <th>Repetition of purchasing</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1004891</td>
      <td>Street Pharmacy</td>
      <td>Oct</td>
      <td>2017-10-11</td>
      <td>2017</td>
      <td>TFTJ0014TS</td>
      <td>Divido D. R. Caps 75Mg</td>
      <td>50</td>
      <td>50</td>
      <td>65.0</td>
      <td>3250.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3250.0</td>
      <td>7000198</td>
      <td>Q4</td>
      <td>LVC</td>
      <td>Low sales</td>
      <td>UN REG</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1004616</td>
      <td>Street Pharmacy</td>
      <td>Feb</td>
      <td>2017-02-26</td>
      <td>2017</td>
      <td>TFCA0014TS</td>
      <td>Zinoximor 500 Mg</td>
      <td>50</td>
      <td>50</td>
      <td>113.0</td>
      <td>5650.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5650.0</td>
      <td>7000259</td>
      <td>Q1</td>
      <td>LVC</td>
      <td>Low sales</td>
      <td>UN REG</td>
    </tr>
  </tbody>
</table>
</div>




```python
## data imformations (non null count in each column ,data type for each column ,range index )
sale.info()

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2959 entries, 0 to 2958
    Data columns (total 19 columns):
     #   Column                     Non-Null Count  Dtype         
    ---  ------                     --------------  -----         
     0   Customer ID                2959 non-null   int64         
     1   Customer_Group             2955 non-null   object        
     2   Period                     2959 non-null   object        
     3   PostDate                   2959 non-null   datetime64[ns]
     4   Year                       2959 non-null   int64         
     5   Material ID                2959 non-null   object        
     6   Material_Descriptions      2959 non-null   object        
     7   Quantity                   2959 non-null   int64         
     8   Qty_Sales                  2959 non-null   int64         
     9   Unit price                 2065 non-null   float64       
     10  Revenue                    2959 non-null   float64       
     11  Discount                   2959 non-null   float64       
     12  DIS%                       2959 non-null   float64       
     13  Net_Sales                  2959 non-null   float64       
     14  Employee ID                2959 non-null   int64         
     15  Quartar                    2959 non-null   object        
     16  Purchasing Power           2959 non-null   object        
     17  Sales Value                2959 non-null   object        
     18  Repetition of purchasing   2959 non-null   object        
    dtypes: datetime64[ns](1), float64(5), int64(5), object(8)
    memory usage: 439.4+ KB
    

## *Data Clean*


```python
### cheking for Null values
sale.isnull().sum()

```




    Customer ID                    0
    Customer_Group                 4
    Period                         0
    PostDate                       0
    Year                           0
    Material ID                    0
    Material_Descriptions          0
    Quantity                       0
    Qty_Sales                      0
    Unit price                   894
    Revenue                        0
    Discount                       0
    DIS%                           0
    Net_Sales                      0
    Employee ID                    0
    Quartar                        0
    Purchasing Power               0
    Sales Value                    0
    Repetition of purchasing       0
    dtype: int64




```python
sale[sale['Customer_Group'].isnull()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Customer_Group</th>
      <th>Period</th>
      <th>PostDate</th>
      <th>Year</th>
      <th>Material ID</th>
      <th>Material_Descriptions</th>
      <th>Quantity</th>
      <th>Qty_Sales</th>
      <th>Unit price</th>
      <th>Revenue</th>
      <th>Discount</th>
      <th>DIS%</th>
      <th>Net_Sales</th>
      <th>Employee ID</th>
      <th>Quartar</th>
      <th>Purchasing Power</th>
      <th>Sales Value</th>
      <th>Repetition of purchasing</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1759</th>
      <td>1012379</td>
      <td>NaN</td>
      <td>Oct</td>
      <td>2017-10-17</td>
      <td>2017</td>
      <td>TFMX0014TS</td>
      <td>Rapidus 50 Mg Tab</td>
      <td>225</td>
      <td>0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7000132</td>
      <td>Q4</td>
      <td>LVC</td>
      <td>Low sales</td>
      <td>UN REG</td>
    </tr>
    <tr>
      <th>1760</th>
      <td>1012379</td>
      <td>NaN</td>
      <td>Oct</td>
      <td>2017-10-17</td>
      <td>2017</td>
      <td>TFMX0014TS</td>
      <td>Rapidus 50 Mg Tab</td>
      <td>500</td>
      <td>500</td>
      <td>55.0</td>
      <td>27500.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>27500.0</td>
      <td>7000132</td>
      <td>Q4</td>
      <td>LVC</td>
      <td>Low sales</td>
      <td>UN REG</td>
    </tr>
    <tr>
      <th>1761</th>
      <td>1012379</td>
      <td>NaN</td>
      <td>Oct</td>
      <td>2017-10-19</td>
      <td>2017</td>
      <td>TFNA0014TS</td>
      <td>Genso 500Mg Caps</td>
      <td>10</td>
      <td>0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7000132</td>
      <td>Q4</td>
      <td>LVC</td>
      <td>Low sales</td>
      <td>UN REG</td>
    </tr>
    <tr>
      <th>1762</th>
      <td>1012379</td>
      <td>NaN</td>
      <td>Oct</td>
      <td>2017-10-19</td>
      <td>2017</td>
      <td>TFNA0014TS</td>
      <td>Genso 500Mg Caps</td>
      <td>100</td>
      <td>100</td>
      <td>65.0</td>
      <td>6500.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>6500.0</td>
      <td>7000132</td>
      <td>Q4</td>
      <td>LVC</td>
      <td>Low sales</td>
      <td>UN REG</td>
    </tr>
  </tbody>
</table>
</div>



#### In the ‘Unit Price’ column, there are 894 missing values.
#### Replace these missing values with zeros.


```python
sale['Unit price '].fillna(0, inplace=True)
```


#### There is 4 Missing Values in Customer_Group Columns 
#### The 4 Missing Values have a Unique Customer ID I Will Fix that
####  by Applying New Customer Group Name "Unknown"


```python
### Replace NaN values in the 'Customer Group' column with 'Unknown'
sale['Customer_Group'].fillna('Unknown', inplace=True)
```


```python
##check the data
sale['Customer_Group'].unique()
```




    array(['Street Pharmacy', 'Sub Agent', 'Chain Pharmacy', 'Polyclinic',
           'Government', 'Hospitals', 'Wholesaler', 'Unknown',
           'Internal Employee'], dtype=object)




##### In the ‘Quantity’, ‘Qty_Sales’, ‘Revenue’, ‘Net_Sales’, ‘Unit price’, and ‘Discount’ columns, there is a minus sign. 
##### This was an entry mistake, and we need to remove it.


```python
sale['Discount'] = sale['Discount'].abs() 
```


```python
sale['Quantity'] = sale['Quantity'].abs()
```


```python
sale['Qty_Sales'] = sale['Qty_Sales'].abs()
```


```python
sale['Revenue'] = sale['Revenue'].abs()
```


```python
sale['Net_Sales'] = sale['Net_Sales'].abs()
```


```python
sale['Unit price '] = sale['Unit price '].abs()
```

### Exploratory Data Analysis (EDA)



```python
 ## Number of rows and columns 
sale.shape
```




    (2959, 19)




```python
## describe the data 
sale[['Qty_Sales','Quantity','Revenue','Discount','Qty_Sales','Net_Sales']].describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Qty_Sales</th>
      <th>Quantity</th>
      <th>Revenue</th>
      <th>Discount</th>
      <th>Qty_Sales</th>
      <th>Net_Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2959.000000</td>
      <td>2959.000000</td>
      <td>2.959000e+03</td>
      <td>2959.000000</td>
      <td>2959.000000</td>
      <td>2.959000e+03</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1277.877661</td>
      <td>1462.660020</td>
      <td>4.975913e+04</td>
      <td>646.177928</td>
      <td>1277.877661</td>
      <td>4.911295e+04</td>
    </tr>
    <tr>
      <th>std</th>
      <td>6892.942831</td>
      <td>7158.653668</td>
      <td>2.173660e+05</td>
      <td>8423.466755</td>
      <td>6892.942831</td>
      <td>2.162461e+05</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.000000</td>
      <td>10.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>20.000000</td>
      <td>50.000000</td>
      <td>1.400000e+03</td>
      <td>0.000000</td>
      <td>20.000000</td>
      <td>1.400000e+03</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>150.000000</td>
      <td>285.000000</td>
      <td>1.319000e+04</td>
      <td>0.000000</td>
      <td>150.000000</td>
      <td>1.319000e+04</td>
    </tr>
    <tr>
      <th>max</th>
      <td>100000.000000</td>
      <td>100000.000000</td>
      <td>4.634239e+06</td>
      <td>364000.000000</td>
      <td>100000.000000</td>
      <td>4.634239e+06</td>
    </tr>
  </tbody>
</table>
</div>




```python
## Repetition of purchasing count 

sale['Repetition of purchasing '].value_counts()
```




    UN REG    2480
    REG        454
    Unique      25
    Name: Repetition of purchasing , dtype: int64




```python
## show  count of Material_Descriptions (Names of the products)

sale['Material_Descriptions'].value_counts()
```




    Rapidus 50 Mg Tab         946
    Meiact 200Mg              713
    Zinoximor 500 Mg          551
    Divido D. R. Caps 75Mg    383
    Zinoxime 1.5 Gm           164
    Genso 500Mg Caps          103
    Zinoxime 750 Mg            98
    Genso Syrup                 1
    Name: Material_Descriptions, dtype: int64




```python
#Purchasing Power count
sale['Purchasing Power'].value_counts()
```




    LVC    1825
    HVC     573
    MVC     561
    Name: Purchasing Power, dtype: int64




```python
##sale Values count
sale['Sales Value '].value_counts()
```




    Low sales    1825
    M sales       561
    H sales       320
    HV sales      253
    Name: Sales Value , dtype: int64




```python
##Customer group names count
sale['Customer_Group'].value_counts()
```




    Street Pharmacy      1408
    Chain Pharmacy        408
    Sub Agent             252
    Government            231
    Hospitals             194
    Wholesaler            163
    Polyclinic            156
    Internal Employee     143
    Unknown                 4
    Name: Customer_Group, dtype: int64




```python
##crosstabe Customer Group & Repetition of purchasing
pd.crosstab( sale['Customer_Group'] , sale['Repetition of purchasing '] , margins=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Repetition of purchasing</th>
      <th>REG</th>
      <th>UN REG</th>
      <th>Unique</th>
      <th>All</th>
    </tr>
    <tr>
      <th>Customer_Group</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Chain Pharmacy</th>
      <td>78</td>
      <td>330</td>
      <td>0</td>
      <td>408</td>
    </tr>
    <tr>
      <th>Government</th>
      <td>0</td>
      <td>229</td>
      <td>2</td>
      <td>231</td>
    </tr>
    <tr>
      <th>Hospitals</th>
      <td>38</td>
      <td>156</td>
      <td>0</td>
      <td>194</td>
    </tr>
    <tr>
      <th>Internal Employee</th>
      <td>0</td>
      <td>143</td>
      <td>0</td>
      <td>143</td>
    </tr>
    <tr>
      <th>Polyclinic</th>
      <td>52</td>
      <td>104</td>
      <td>0</td>
      <td>156</td>
    </tr>
    <tr>
      <th>Street Pharmacy</th>
      <td>157</td>
      <td>1251</td>
      <td>0</td>
      <td>1408</td>
    </tr>
    <tr>
      <th>Sub Agent</th>
      <td>116</td>
      <td>130</td>
      <td>6</td>
      <td>252</td>
    </tr>
    <tr>
      <th>Unknown</th>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>Wholesaler</th>
      <td>13</td>
      <td>133</td>
      <td>17</td>
      <td>163</td>
    </tr>
    <tr>
      <th>All</th>
      <td>454</td>
      <td>2480</td>
      <td>25</td>
      <td>2959</td>
    </tr>
  </tbody>
</table>
</div>




```python
## crosstabe Customer Group & Material_Descriptions
pd.crosstab(  sale.Customer_Group,sale.Material_Descriptions, margins=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Material_Descriptions</th>
      <th>Divido D. R. Caps 75Mg</th>
      <th>Genso 500Mg Caps</th>
      <th>Genso Syrup</th>
      <th>Meiact 200Mg</th>
      <th>Rapidus 50 Mg Tab</th>
      <th>Zinoxime 1.5 Gm</th>
      <th>Zinoxime 750 Mg</th>
      <th>Zinoximor 500 Mg</th>
      <th>All</th>
    </tr>
    <tr>
      <th>Customer_Group</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Chain Pharmacy</th>
      <td>45</td>
      <td>16</td>
      <td>0</td>
      <td>96</td>
      <td>148</td>
      <td>35</td>
      <td>0</td>
      <td>68</td>
      <td>408</td>
    </tr>
    <tr>
      <th>Government</th>
      <td>80</td>
      <td>1</td>
      <td>0</td>
      <td>17</td>
      <td>7</td>
      <td>22</td>
      <td>34</td>
      <td>70</td>
      <td>231</td>
    </tr>
    <tr>
      <th>Hospitals</th>
      <td>20</td>
      <td>6</td>
      <td>0</td>
      <td>54</td>
      <td>54</td>
      <td>17</td>
      <td>0</td>
      <td>43</td>
      <td>194</td>
    </tr>
    <tr>
      <th>Internal Employee</th>
      <td>15</td>
      <td>4</td>
      <td>1</td>
      <td>36</td>
      <td>47</td>
      <td>8</td>
      <td>6</td>
      <td>26</td>
      <td>143</td>
    </tr>
    <tr>
      <th>Polyclinic</th>
      <td>20</td>
      <td>0</td>
      <td>0</td>
      <td>47</td>
      <td>47</td>
      <td>12</td>
      <td>0</td>
      <td>30</td>
      <td>156</td>
    </tr>
    <tr>
      <th>Street Pharmacy</th>
      <td>124</td>
      <td>51</td>
      <td>0</td>
      <td>379</td>
      <td>553</td>
      <td>50</td>
      <td>2</td>
      <td>249</td>
      <td>1408</td>
    </tr>
    <tr>
      <th>Sub Agent</th>
      <td>39</td>
      <td>15</td>
      <td>0</td>
      <td>67</td>
      <td>58</td>
      <td>19</td>
      <td>8</td>
      <td>46</td>
      <td>252</td>
    </tr>
    <tr>
      <th>Unknown</th>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>Wholesaler</th>
      <td>40</td>
      <td>8</td>
      <td>0</td>
      <td>17</td>
      <td>30</td>
      <td>1</td>
      <td>48</td>
      <td>19</td>
      <td>163</td>
    </tr>
    <tr>
      <th>All</th>
      <td>383</td>
      <td>103</td>
      <td>1</td>
      <td>713</td>
      <td>946</td>
      <td>164</td>
      <td>98</td>
      <td>551</td>
      <td>2959</td>
    </tr>
  </tbody>
</table>
</div>



###  Which Month  has the highest net sales?


```python
## Sum of NetSale Groupby Month

Month_Net=sale.groupby('Period')['Net_Sales'].sum().sort_values(ascending=False)
Month_Net
```




    Period
    Sep    24607004.23
    Oct    23500170.28
    Mar    13229106.90
    Dec    11953623.96
    Jul    11689157.10
    Aug    11490441.84
    Jun    10537582.79
    Apr     9669502.80
    Jan     9431725.20
    Feb     7679390.70
    Nov     7219328.48
    May     4318192.80
    Name: Net_Sales, dtype: float64




```python
#plot Net_Sale & Month
Month_Net.plot(kind='bar', title='Total  Net Sale by Months', ylabel='Net Sale', xlabel='Months',color=('#510400','#D03D56'), figsize=(10, 6))
plt.xticks(rotation=0) 
plt.show()
```


    
![png](output_34_0.png)
    


###  Which Month  has the highest  Qty_Sales?


```python
## Qty sale Groupby Month
Month_Net2=sale.groupby('Period')['Qty_Sales'].sum().sort_values(ascending=False)
Month_Net2
```




    Period
    Sep    818208
    Oct    529523
    Dec    468511
    Aug    330125
    Nov    322868
    Feb    262310
    Jan    257314
    Mar    245579
    Jul    192770
    Jun    150843
    Apr    145857
    May     57332
    Name: Qty_Sales, dtype: int64




```python
##plot Qty_Sale & Month

Month_Net2.plot(kind='bar', title='Total Qty Sale by Months', ylabel='Qty Sale', xlabel= 'Months' ,color=('#510400','#D03D56'), figsize=(10, 6))
plt.xticks(rotation=0) 
plt.show()
```


    
![png](output_37_0.png)
    


### Which quarter has the highest net sales?


```python
## Total Qty Sale & Quartar
Quartar_Net=sale.groupby('Quartar')['Net_Sales'].sum().sort_values(ascending=False)
Quartar_Net

```




    Quartar
    Q3    47786603.17
    Q4    42673122.72
    Q1    30340222.80
    Q2    24525278.39
    Name: Net_Sales, dtype: float64




```python
##plot Qty_Sale & Quartar
Quartar_Net.plot(kind='bar', title='Total Net Sale by Quartar', ylabel='Net Sale', xlabel= 'Quartar' ,color=('#510400','#D03D56'), figsize=(10,6))
plt.xticks(rotation=0) 
plt.show()
```


    
![png](output_40_0.png)
    


### Which quarter has the highest Qty_Sales ?


```python
## Total Qty Sale Groupby Quarter
Quartar_Net1=sale.groupby('Quartar')['Qty_Sales'].sum().sort_values(ascending=False)
Quartar_Net1

```




    Quartar
    Q3    1341103
    Q4    1320902
    Q1     765203
    Q2     354032
    Name: Qty_Sales, dtype: int64




```python
##plot Qty_Sale & Quartar
Quartar_Net1.plot(kind='bar', title='Total Qty_Salesby Quartar', ylabel='Qty_Sales', xlabel= 'Quartar' ,color=('#510400','#D03D56'), figsize=(10,6))
plt.xticks(rotation=0) 
plt.show()


```


    
![png](output_43_0.png)
    


### Which Customer Group has the highest Net Sale ?    


```python
Customer=sale.groupby('Customer_Group')['Net_Sales'].sum().sort_values(ascending=False)
Customer

```




    Customer_Group
    Wholesaler           64501063.02
    Government           35090408.00
    Sub Agent            26598848.96
    Chain Pharmacy        5628693.45
    Street Pharmacy       4638299.15
    Hospitals             4524806.00
    Polyclinic            4309108.50
    Unknown                 34000.00
    Internal Employee           0.00
    Name: Net_Sales, dtype: float64




```python
##plot Net Sale& Customer G roup
Customer.plot(kind='bar', title='Total Net Sale by Customer Group', ylabel='Net Sale', xlabel= 'Customer Group', color=('#510400','#D03D56'), figsize=(12,6))
plt.xticks(rotation=0) 
plt.show()
```


    
![png](output_46_0.png)
    


### Which Customer Group has the highest Qty Sale ?  


```python
##total Qty Saly & Customer_Group
Customer1=sale.groupby('Customer_Group')['Qty_Sales'].sum().sort_values(ascending=False)
Customer1
```




    Customer_Group
    Wholesaler           2063139
    Government           1007383
    Sub Agent             465843
    Chain Pharmacy         79216
    Street Pharmacy        62064
    Hospitals              56055
    Polyclinic             46940
    Unknown                  600
    Internal Employee          0
    Name: Qty_Sales, dtype: int64




```python
##plot Qty Sale & Customer Group
Customer1.plot(kind='bar', title='Total Qty Sales by Customer Group', ylabel='Qty Sales', xlabel= 'Customer Group', color=('#510400','#D03D56'), figsize=(12,6))
plt.xticks(rotation=0) 
plt.show()
```


    
![png](output_49_0.png)
    


 ### Which  Product Have Highst Net Sales


```python
Material=sale.groupby('Material_Descriptions')['Net_Sales'].sum().sort_values(ascending=False)
Material
```




    Material_Descriptions
    Zinoxime 750 Mg           42664664.62
    Divido D. R. Caps 75Mg    41897571.60
    Zinoximor 500 Mg          30060542.60
    Meiact 200Mg              11864041.08
    Rapidus 50 Mg Tab         10691154.08
    Zinoxime 1.5 Gm            6686118.10
    Genso 500Mg Caps           1461135.00
    Genso Syrup                      0.00
    Name: Net_Sales, dtype: float64




```python
##plot Qty Sale & Material_Descriptions
Material.plot(kind='bar', title='Total Net Sales by Material_Descriptions', ylabel='Net Sales', xlabel= 'Material_Descriptions', color=('#510400','#D03D56'), figsize=(15,6))
plt.xticks(rotation=0) 
plt.show()
```


    
![png](output_52_0.png)
    


### Which Product has the highest Net Sale ?  


```python
##product & Net Sale
Material1=sale.groupby('Material_Descriptions')['Net_Sales'].sum().sort_values(ascending=False)
Material1
```




    Material_Descriptions
    Zinoxime 750 Mg           42664664.62
    Divido D. R. Caps 75Mg    41897571.60
    Zinoximor 500 Mg          30060542.60
    Meiact 200Mg              11864041.08
    Rapidus 50 Mg Tab         10691154.08
    Zinoxime 1.5 Gm            6686118.10
    Genso 500Mg Caps           1461135.00
    Genso Syrup                      0.00
    Name: Net_Sales, dtype: float64




```python
##plot Net Sale & Material_Descriptions(product)
Material1.plot(kind='bar', title='Total Qty Sales by Material_Descriptions', ylabel='Net_Sales', xlabel= 'Material Descriptions', color=('#510400','#D03D56'), figsize=(15,6))
plt.xticks(rotation=0) 
plt.show()

```


    
![png](output_55_0.png)
    


### Which Product has the highest Net Qty Sale? 


```python
## Product & Qty Sale
Material3=sale.groupby('Material_Descriptions')['Qty_Sales'].count().sort_values(ascending=False)
Material3

```




    Material_Descriptions
    Rapidus 50 Mg Tab         946
    Meiact 200Mg              713
    Zinoximor 500 Mg          551
    Divido D. R. Caps 75Mg    383
    Zinoxime 1.5 Gm           164
    Genso 500Mg Caps          103
    Zinoxime 750 Mg            98
    Genso Syrup                 1
    Name: Qty_Sales, dtype: int64




```python
##plot Qty Sale& Material_Descriptions(product)

Material1.plot(kind='bar', title='Total Qty Sales by Material_Descriptions', ylabel='Qty_Sale', xlabel= 'Material Descriptions', color=('#510400','#D03D56'), figsize=(15,6))
plt.xticks(rotation=0) 
plt.show()
```


    
![png](output_58_0.png)
    


## Correlation


```python
sale.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Customer_Group</th>
      <th>Period</th>
      <th>PostDate</th>
      <th>Year</th>
      <th>Material ID</th>
      <th>Material_Descriptions</th>
      <th>Quantity</th>
      <th>Qty_Sales</th>
      <th>Unit price</th>
      <th>Revenue</th>
      <th>Discount</th>
      <th>DIS%</th>
      <th>Net_Sales</th>
      <th>Employee ID</th>
      <th>Quartar</th>
      <th>Purchasing Power</th>
      <th>Sales Value</th>
      <th>Repetition of purchasing</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1004891</td>
      <td>Street Pharmacy</td>
      <td>Oct</td>
      <td>2017-10-11</td>
      <td>2017</td>
      <td>TFTJ0014TS</td>
      <td>Divido D. R. Caps 75Mg</td>
      <td>50</td>
      <td>50</td>
      <td>65.0</td>
      <td>3250.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3250.0</td>
      <td>7000198</td>
      <td>Q4</td>
      <td>LVC</td>
      <td>Low sales</td>
      <td>UN REG</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Calculate Pearson's correlation between  Net Sales & Discount ,Qty Sales and Unit Price
corr_Net_Sales1 = np.corrcoef(sale['Discount'] , sale['Net_Sales'])[0, 1]
corr_Net_Sales = np.corrcoef(sale['Unit price '] , sale['Net_Sales'])[0, 1]
corr_Qty_Sales1= np.corrcoef(sale['Qty_Sales'],sale['Net_Sales'])[0, 1]
corr_Qty_Sales= np.corrcoef(sale['Qty_Sales'],sale['Revenue'])[0, 1]
corr_Unit_Price= np.corrcoef(sale['Unit price '],sale['Revenue'])[0, 1]
print(f"Pearson's correlation (Discount  VS  Net_Sales) = { corr_Net_Sales1:.2f}")
print(f"Pearson's correlation (Unit Price  VS  Net_Sales) = { corr_Net_Sales:.2f}")
print(f"Pearson's correlation (Qty_SaleS VS  Net_Sales) = {corr_Qty_Sales1:.2f}")
print(f"Pearson's correlation (Qty_Sales VS  Revenue) = {corr_Qty_Sales:.2f}")
print(f"Pearson's correlation (Unit Price VS  Revenue) = {corr_Unit_Price:.2f}")
 
```

    Pearson's correlation (Discount  VS  Net_Sales) = 0.11
    Pearson's correlation (Unit Price  VS  Net_Sales) = -0.01
    Pearson's correlation (Qty_SaleS VS  Net_Sales) = 0.89
    Pearson's correlation (Qty_Sales VS  Revenue) = 0.88
    Pearson's correlation (Unit Price VS  Revenue) = -0.01
    


```python
##sale['Revenue'].corr(sale['Unit price '])
```

### Build a model to predict revenue.

### 1- The inputs (regressors, 𝑥) and output (response, 𝑦) 
### should be arrays or similar objects. This is the way of providing data for regression:-


```python
x = np.array(sale['Qty_Sales']).reshape((-1, 1))
>>> y = np.array(sale['Revenue'])
x
```




    array([[  50],
           [  50],
           [   5],
           ...,
           [   0],
           [   0],
           [1000]], dtype=int64)



### 2- create a linear regression model and fit it using the existing data:-


```python
model = LinearRegression().fit(x, y)

```

### The attributes of model are  coefficient 𝑏₀, and  𝑏₁:


```python
 ### a trailing underscore indicates that an attribute is estimated. 
print(f"𝑏₀: {model.intercept_}") 

print(f"𝑏₁: {model.coef_}")

```

    𝑏₀: 14103.936858021349
    𝑏₁: [27.90188362]
    

### 3-Predict response


```python
 Revenue_pred = model.intercept_ + model.coef_ * x
>>> print(f"predicted Revenue:\n{Revenue_pred}")

```

    predicted Revenue:
    [[15499.03103886]
     [15499.03103886]
     [14243.44627611]
     ...
     [14103.93685802]
     [14103.93685802]
     [42005.8204748 ]]
    

 ### 4-obtain the coefficient of determination, 𝑅²


```python
 r_sq = model.score(x, y)
>>> print(f"𝑅²= {r_sq}")
```

    𝑅²= 0.782876586527637
    

### Build a model to predict Net Sale.

1- The inputs (regressors, 𝑥1) and output (response, 𝑦1)
should be arrays or similar objects. This is the way of providing data for regression:-


```python
x1 = np.array (sale['Qty_Sales']).reshape((-1, 1))
y1 = np.array(sale['Revenue'])
x1
```




    array([[  50],
           [  50],
           [   5],
           ...,
           [   0],
           [   0],
           [1000]], dtype=int64)



### 2- create a linear regression model and fit it using the existing data:-


```python
mode2 = LinearRegression().fit(x1, y1)

```

### 3-The attributes of model are  coefficient 𝑏₀, and  𝑏₁:


```python
### a trailing underscore indicates that an attribute is estimated. 
print(f"𝑏₀₀: {model.intercept_}") 

print(f"𝑏₁₁: {model.coef_}")
```

    𝑏₀₀: 14103.936858021349
    𝑏₁₁: [27.90188362]
    

### 4-Predict response


```python
Revenue_pred = model.intercept_ + model.coef_ * x
>>> print(f"predicted Revenue:\n{Revenue_pred}")
```

    predicted Revenue:
    [[15499.03103886]
     [15499.03103886]
     [14243.44627611]
     ...
     [14103.93685802]
     [14103.93685802]
     [42005.8204748 ]]
    

### 4-obtain the coefficient of determination, 𝑅²


```python
 r_sq = model.score(x, y)
>>> print(f"𝑅²= {r_sq}")
```

    𝑅²= 0.782876586527637
    


```python
x2 = np.array (sale['Qty_Sales'],['Unit price ']).reshape((-1, 1))
y2 = np.array(sale['Revenue'])
x2
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    ~\AppData\Local\Temp\ipykernel_10328\3440530685.py in <module>
    ----> 1 x2 = np.array (sale['Qty_Sales'],['Unit price ']).reshape((-1, 1))
          2 y2 = np.array(sale['Revenue'])
          3 x2
    

    TypeError: Field elements must be 2- or 3-tuples, got ''Unit price ''



```python
sale.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Customer_Group</th>
      <th>Period</th>
      <th>PostDate</th>
      <th>Year</th>
      <th>Material ID</th>
      <th>Material_Descriptions</th>
      <th>Quantity</th>
      <th>Qty_Sales</th>
      <th>Unit price</th>
      <th>Revenue</th>
      <th>Discount</th>
      <th>DIS%</th>
      <th>Net_Sales</th>
      <th>Employee ID</th>
      <th>Quartar</th>
      <th>Purchasing Power</th>
      <th>Sales Value</th>
      <th>Repetition of purchasing</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1004891</td>
      <td>Street Pharmacy</td>
      <td>Oct</td>
      <td>2017-10-11</td>
      <td>2017</td>
      <td>TFTJ0014TS</td>
      <td>Divido D. R. Caps 75Mg</td>
      <td>50</td>
      <td>50</td>
      <td>65.0</td>
      <td>3250.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3250.0</td>
      <td>7000198</td>
      <td>Q4</td>
      <td>LVC</td>
      <td>Low sales</td>
      <td>UN REG</td>
    </tr>
  </tbody>
</table>
</div>




```python
##sns.pairplot(sale, x_vars=['Material_Descriptions', 'Customer_Group', 'Period'], y_vars='Revenue', size=8, aspect=.6)
```


```python
f_statistic, p_value = stats.f_oneway(*[group['Net_Sales'] for name, group in sale.groupby('Material_Descriptions')])
f_statistic, p_value
```




    (64.16283022451962, 2.6618524689216297e-86)




```python
f_statistic, p_value = stats.f_oneway(*[group['Net_Sales'] for name, group in sale.groupby('Customer_Group')])
f_statistic, p_value
```




    (88.78738533730872, 2.5001360412914578e-132)



# live


```python
sale[['Customer ID','Qty_Sales']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Qty_Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1004891</td>
      <td>50</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1004616</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1004616</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1004616</td>
      <td>20</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1011065</td>
      <td>5</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2954</th>
      <td>1004078</td>
      <td>100</td>
    </tr>
    <tr>
      <th>2955</th>
      <td>1004078</td>
      <td>100</td>
    </tr>
    <tr>
      <th>2956</th>
      <td>1004078</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2957</th>
      <td>1007577</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2958</th>
      <td>1007577</td>
      <td>1000</td>
    </tr>
  </tbody>
</table>
<p>2959 rows × 2 columns</p>
</div>




```python
sale.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Customer_Group</th>
      <th>Period</th>
      <th>PostDate</th>
      <th>Year</th>
      <th>Material ID</th>
      <th>Material_Descriptions</th>
      <th>Quantity</th>
      <th>Qty_Sales</th>
      <th>Unit price</th>
      <th>Revenue</th>
      <th>Discount</th>
      <th>DIS%</th>
      <th>Net_Sales</th>
      <th>Employee ID</th>
      <th>Quartar</th>
      <th>Purchasing Power</th>
      <th>Sales Value</th>
      <th>Repetition of purchasing</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1004891</td>
      <td>Street Pharmacy</td>
      <td>Oct</td>
      <td>2017-10-11</td>
      <td>2017</td>
      <td>TFTJ0014TS</td>
      <td>Divido D. R. Caps 75Mg</td>
      <td>50</td>
      <td>50</td>
      <td>65.0</td>
      <td>3250.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3250.0</td>
      <td>7000198</td>
      <td>Q4</td>
      <td>LVC</td>
      <td>Low sales</td>
      <td>UN REG</td>
    </tr>
  </tbody>
</table>
</div>




```python
##sale['Revenue'].describe()
```


```python
sale[['Quantity', 'Qty_Sales', 'Unit price ' ,'Revenue','Net_Sales']].corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Quantity</th>
      <th>Qty_Sales</th>
      <th>Unit price</th>
      <th>Revenue</th>
      <th>Net_Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Quantity</th>
      <td>1.000000</td>
      <td>0.958266</td>
      <td>-0.193364</td>
      <td>0.847017</td>
      <td>0.849455</td>
    </tr>
    <tr>
      <th>Qty_Sales</th>
      <td>0.958266</td>
      <td>1.000000</td>
      <td>-0.193364</td>
      <td>0.885219</td>
      <td>0.887709</td>
    </tr>
    <tr>
      <th>Unit price</th>
      <td>-0.193364</td>
      <td>-0.193364</td>
      <td>1.000000</td>
      <td>-0.131813</td>
      <td>-0.131895</td>
    </tr>
    <tr>
      <th>Revenue</th>
      <td>0.847017</td>
      <td>0.885219</td>
      <td>-0.131813</td>
      <td>1.000000</td>
      <td>0.999265</td>
    </tr>
    <tr>
      <th>Net_Sales</th>
      <td>0.849455</td>
      <td>0.887709</td>
      <td>-0.131895</td>
      <td>0.999265</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
y=sale[['Net_Sales']]
x=sale[['Quantity','Qty_Sales']]
```


```python
x=sm.add_constant(x)
results=sm.OLS(y,x).fit()
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>Net_Sales</td>    <th>  R-squared:         </th> <td>   0.787</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.787</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   5472.</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 29 Apr 2024</td> <th>  Prob (F-statistic):</th>  <td>  0.00</td>  
</tr>
<tr>
  <th>Time:</th>                 <td>00:02:03</td>     <th>  Log-Likelihood:    </th> <td> -38257.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  2959</td>      <th>  AIC:               </th> <td>7.652e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  2956</td>      <th>  BIC:               </th> <td>7.654e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     2</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
      <td></td>         <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>     <td> 1.366e+04</td> <td> 1872.986</td> <td>    7.291</td> <td> 0.000</td> <td> 9982.753</td> <td> 1.73e+04</td>
</tr>
<tr>
  <th>Quantity</th>  <td>   -0.5953</td> <td>    0.894</td> <td>   -0.665</td> <td> 0.506</td> <td>   -2.349</td> <td>    1.159</td>
</tr>
<tr>
  <th>Qty_Sales</th> <td>   28.4287</td> <td>    0.929</td> <td>   30.603</td> <td> 0.000</td> <td>   26.607</td> <td>   30.250</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>4211.666</td> <th>  Durbin-Watson:     </th>  <td>   1.475</td>  
</tr>
<tr>
  <th>Prob(Omnibus):</th>  <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>1950707.292</td>
</tr>
<tr>
  <th>Skew:</th>           <td> 8.136</td>  <th>  Prob(JB):          </th>  <td>    0.00</td>  
</tr>
<tr>
  <th>Kurtosis:</th>       <td>127.728</td> <th>  Cond. No.          </th>  <td>1.02e+04</td>  
</tr>
</table><br/><br/>Notes:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 1.02e+04. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
##sale_s=sale.duplicated()
sale_s
```




    0       False
    1       False
    2       False
    3       False
    4       False
            ...  
    2954    False
    2955    False
    2956    False
    2957    False
    2958    False
    Length: 2959, dtype: bool


